WebsiteChat.net Live Chat Box

Copyright (c) 2010 WebsiteChat.net
Released under the GNU General Public License

Version 1.2  WebsiteChat.net
             http://websitechat.net

Install guide: http://websitechat.net/en/3rd-party/oscommerce-231
Demo at:       http://oscommerce.live-support-chat.co.cc/websitechat.net/

---------------------------------------------------------------------

This contribution creates a box on your site with a Live Chat button.
It allows your website visitors to connect to a company support team
and have their questions answered instantly by clicking on a Live Chat
button. Live Chat on your website improves customer satisfaction and
helps to generate instant sales leads.

---------------------------------------------------------------------

See: http://websitechat.net/en/3rd-party/oscommerce-231

or follow installation instructions below:

1. Create an account at http://websitechat.net/en/register 
   and login into Control Panel at http://websitechat.net/login

2. Select "Chat Buttons" in "My Account" panel and copy the HTML code.

3. Upload bm_live_chat.php to /catalog/includes/modules/boxes/ via ftp

5. Login to your osCommerce administration panel and follow steps below:
   - Go to Modules -> Boxes
   - Install Live Chat module
   - Edit Live Chat module settings and paste HTML button code
   - Enable the module and Live Chat button will be displayed in your shop


