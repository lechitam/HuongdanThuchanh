<?php
/*
  $Id$

  WebsiteChat.net Live Chat Box
  http://websitechat.net

  Copyright (c) 2012 WebsiteChat.net

  Released under the GNU General Public License
*/

  class bm_live_chat {
    
    var $code = 'bm_live_chat';
    var $group = 'boxes';
    var $title;
    var $description;
    var $sort_order;
    var $enabled = false;

    function bm_live_chat() {
      
      $this->title = 'Live Chat module';
      
      $this->description = 'Live Chat module';

      if ( defined('MODULE_BOXES_LIVE_CHAT_STATUS') ) {
        
        $this->sort_order = MODULE_BOXES_LIVE_CHAT_ORDER;
        
        $this->enabled = (MODULE_BOXES_LIVE_CHAT_STATUS == 'True');

        $this->group = ((MODULE_BOXES_LIVE_CHAT_CONTENT_PLACEMENT == 'Left Column') ? 'boxes_column_left' : 'boxes_column_right');
      }
    }

    function execute() {
      global $oscTemplate;
      
      $data = tep_random_select("select configuration_value FROM ".TABLE_CONFIGURATION." WHERE configuration_key = 'MODULE_BOXES_LIVE_CHAT_CODE' LIMIT 1");

      if (!isset($data['configuration_value']) || !$data['configuration_value'])
      {
        $html_code = '<span style="color: gray;">Module not configured</span>';
      }
      else
      {
        $html_code = $data['configuration_value'];
      }
      
      $data = tep_random_select("select configuration_value FROM ".TABLE_CONFIGURATION." WHERE configuration_key = 'MODULE_BOXES_LIVE_CHAT_TITLE' LIMIT 1");

      if (!isset($data['configuration_value']) || !$data['configuration_value'])
      {
        $title = null;
      }
      else
      {
        $title = $data['configuration_value'];
      }
      
      $data = '<div class="ui-widget infoBoxContainer">';
      
      if ($title)
      {
        $data.= '<div class="ui-widget-header infoBoxHeading">'.$title.'</div>';
      }
      
      $data.= '<div class="ui-widget-content infoBoxContents" style="text-align: center;">'.$html_code.'</div></div>';

      $oscTemplate->addBlock($data, $this->group);
    }

    function isEnabled() {
      return $this->enabled;
    }

    function check() {
      return defined('MODULE_BOXES_LIVE_CHAT_STATUS');
    }

    function install() {
      
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable Live Chat Module', 'MODULE_BOXES_LIVE_CHAT_STATUS', 'True', 'Do you want to add the module to your shop?', '6', '1', 'tep_cfg_select_option(array(\'True\', \'False\'), ', now())");
      
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Chat Button Placement', 'MODULE_BOXES_LIVE_CHAT_CONTENT_PLACEMENT', 'Left Column', 'Should the module be loaded in the left or right column?', '6', '1', 'tep_cfg_select_option(array(\'Left Column\', \'Right Column\'), ', now())");
      
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Sort Order', 'MODULE_BOXES_LIVE_CHAT_ORDER', '0', 'Sort order of display. Lowest is displayed first.', '6', '0', now())");
      
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Chat Button HTML code', 'MODULE_BOXES_LIVE_CHAT_CODE', '', 'Paste Chat Button HTML code here', '6', '0', now())");
      
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Box title', 'MODULE_BOXES_LIVE_CHAT_TITLE', '', 'Enter Box title here. Leave blank to disable the title bar.', '6', '0', now())");
    }

    function remove() {
      tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }

    function keys() {
      return array('MODULE_BOXES_LIVE_CHAT_STATUS', 'MODULE_BOXES_LIVE_CHAT_CONTENT_PLACEMENT', 'MODULE_BOXES_LIVE_CHAT_ORDER', 'MODULE_BOXES_LIVE_CHAT_CODE', 'MODULE_BOXES_LIVE_CHAT_TITLE');
    }
  }
?>
